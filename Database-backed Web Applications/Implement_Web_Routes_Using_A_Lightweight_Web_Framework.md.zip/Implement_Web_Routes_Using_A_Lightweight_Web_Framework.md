Code:

import os
from flask import Flask, request

# Create a new Flask app
app = Flask(__name__)

# == Your Routes Here ==

# == Example Code Below ==


@app.route('/goodbye', methods=['POST'])
def goodbye():
    name = request.form['name'] # The value is 'Alice'

    # Send back a fond farewell with the name
    return f"Goodbye {name}!"

@app.route('/hello', methods=['GET'])
def hello():
    name = request.args['name'] # The value is 'David'

    # Send back a friendly greeting with the name
    return f"Hello {name}!"

@app.route('/submit', methods=['POST'])
def intro():
    name = request.form['name'] # The value is 'Leo'
    message = request.form['message'] # The value is 'Hello World'
    # Send back a message with the name
    return f"Thanks {name}, you sent this message: {message}"

@app.route('/wave', methods=['GET'])
def wave():
    name = request.args['name'] # The value is 'Leo'

    # Send back a friendly wave with the name
    return f"I am waving at {name}!"

# This imports some more example routes for you to see how they work
# You can delete these lines if you don't need them.
from example_routes import apply_example_routes
apply_example_routes(app)

# == End Example Code ==

# These lines start the server if you run this file directly
# They also start the server configured to use the test database
# if started in test mode.
if __name__ == '__main__':
    app.run(debug=True, port=int(os.environ.get('PORT', 5001)))

Terminal Output:

joshuadosanjh@MASTUDENT-Joshua-Dosanjh-C17GMAYAQ6L4 ~ % curl -X POST -d "name=Leo&message='Hello World'" http://localhost:5001/submit
Thanks Leo, you sent this message: 'Hello World'%                                                    joshuadosanjh@MASTUDENT-Joshua-Dosanjh-C17GMAYAQ6L4 ~ % curl "http://localhost:5001/hello?name=Leo" 
curl: (7) Failed to connect to localhost port 5001 after 0 ms: Couldn't connect to server
joshuadosanjh@MASTUDENT-Joshua-Dosanjh-C17GMAYAQ6L4 ~ % curl "http://localhost:5001/wave?name=Leo"
curl: (7) Failed to connect to localhost port 5001 after 0 ms: Couldn't connect to server
joshuadosanjh@MASTUDENT-Joshua-Dosanjh-C17GMAYAQ6L4 ~ % curl "http://localhost:5001/wave?name=Leo"
I am waving at Leo!%