# Nights for which a space has already been booked should not be available for users to book that space.	
## Space -> Request(pending) -> Approved request
### List the unavailable dates (Core) on the 'space page'
### Hide them on a date picker (Nice to have)


Handled by requirement 4