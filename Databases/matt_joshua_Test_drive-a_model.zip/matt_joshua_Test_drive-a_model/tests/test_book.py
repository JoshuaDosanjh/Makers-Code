from lib.books import Books

"""
Book constructs with an id, title and author_name
"""
def test_book_constructs():
    book = Books(1,'Test Book', 'Test Author')
    assert book.id == 1
    assert book.title == "Test Book"
    assert book.author_name == "Test Author"

