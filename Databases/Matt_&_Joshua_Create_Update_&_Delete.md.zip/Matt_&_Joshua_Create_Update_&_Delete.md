# Matt and Joshua Create, Update and Delete
joshuadosanjh@MASTUDENT-Joshua-Dosanjh-C17GMAYAQ6L4 databases % psql -h 127.0.0.1       
psql (15.7 (Homebrew))
Type "help" for help.

joshuadosanjh=# create database music_library2
joshuadosanjh-# ;
CREATE DATABASE
joshuadosanjh=# \q
joshuadosanjh@MASTUDENT-Joshua-Dosanjh-C17GMAYAQ6L4 databases % psql -h 127.0.0.1 music_library2 < music_library.sql     
zsh: no such file or directory: music_library.sql
joshuadosanjh@MASTUDENT-Joshua-Dosanjh-C17GMAYAQ6L4 databases % psql -h 127.0.0.1 music_library2 < seeds/music_library.sql
NOTICE:  table "artists" does not exist, skipping
DROP TABLE
NOTICE:  sequence "artists_id_seq" does not exist, skipping
DROP SEQUENCE
NOTICE:  table "albums" does not exist, skipping
DROP TABLE
NOTICE:  sequence "albums_id_seq" does not exist, skipping
DROP SEQUENCE
CREATE SEQUENCE
CREATE TABLE
CREATE SEQUENCE
CREATE TABLE
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
INSERT 0 1
joshuadosanjh@MASTUDENT-Joshua-Dosanjh-C17GMAYAQ6L4 databases % psql -h 127.0.0.1                                         
psql (15.7 (Homebrew))
Type "help" for help.

joshuadosanjh=# select * from artists
joshuadosanjh-# ;
ERROR:  relation "artists" does not exist
LINE 1: select * from artists
                      ^
joshuadosanjh=# select * from artist;
ERROR:  relation "artist" does not exist
LINE 1: select * from artist;
                      ^
joshuadosanjh=# select * from music_library2;
ERROR:  relation "music_library2" does not exist
LINE 1: select * from music_library2;
                      ^
joshuadosanjh=# select music_library2 from artists;
ERROR:  relation "artists" does not exist
LINE 1: select music_library2 from artists;
                                   ^
joshuadosanjh=# SELECT * FROM artists;
ERROR:  relation "artists" does not exist
LINE 1: SELECT * FROM artists;
                      ^
joshuadosanjh=# SELECT * FROM artists;
ERROR:  relation "artists" does not exist
LINE 1: SELECT * FROM artists;
                      ^
joshuadosanjh=# \q
joshuadosanjh@MASTUDENT-Joshua-Dosanjh-C17GMAYAQ6L4 databases % psql -h 127.0.0.1 music_library2
psql (15.7 (Homebrew))
Type "help" for help.

music_library2=# SELECT * FROM artists;
 id |     name     | genre 
----+--------------+-------
  1 | Pixies       | Rock
  2 | ABBA         | Pop
  3 | Taylor Swift | Pop
  4 | Nina Simone  | Jazz
(4 rows)

music_library2=# INSERT INTO artists
music_library2-# (name, genre)
music_library2-# VALUES('Talking Heads', 'Pop')
music_library2-# ;
INSERT 0 1
music_library2=# SELECT * FROM artists;
 id |     name      | genre 
----+---------------+-------
  1 | Pixies        | Rock
  2 | ABBA          | Pop
  3 | Taylor Swift  | Pop
  4 | Nina Simone   | Jazz
  5 | Talking Heads | Pop
(5 rows)

music_library2=# SELECT * FROM albums;
 id |        title         | release_year | artist_id 
----+----------------------+--------------+-----------
  1 | Doolittle            |         1989 |         1
  2 | Surfer Rosa          |         1988 |         1
  3 | Waterloo             |         1974 |         2
  4 | Super Trouper        |         1980 |         2
  5 | Bossanova            |         1990 |         1
  6 | Lover                |         2019 |         3
  7 | Folklore             |         2020 |         3
  8 | I Put a Spell on You |         1965 |         4
  9 | Baltimore            |         1978 |         4
 10 | Here Comes the Sun   |         1971 |         4
 11 | Fodder on My Wings   |         1982 |         4
 12 | Ring Ring            |         1973 |         2
(12 rows)

music_library2=# INSERT INTO albums
(title, release_year, artist_id)
VALUES('Creatures of Love', 1982, 5), ('Mama Mamia', 2002, 2), ('The Tortured Poets Department', 2024, 3), ('Grimbly', 2012, 1), ('Glomblesteen', 1997, 4)
;
INSERT 0 5
music_library2=# SELECT * FROM albums;
 id |             title             | release_year | artist_id 
----+-------------------------------+--------------+-----------
  1 | Doolittle                     |         1989 |         1
  2 | Surfer Rosa                   |         1988 |         1
  3 | Waterloo                      |         1974 |         2
  4 | Super Trouper                 |         1980 |         2
  5 | Bossanova                     |         1990 |         1
  6 | Lover                         |         2019 |         3
  7 | Folklore                      |         2020 |         3
  8 | I Put a Spell on You          |         1965 |         4
  9 | Baltimore                     |         1978 |         4
 10 | Here Comes the Sun            |         1971 |         4
 11 | Fodder on My Wings            |         1982 |         4
 12 | Ring Ring                     |         1973 |         2
 13 | Creatures of Love             |         1982 |         5
 14 | Mama Mamia                    |         2002 |         2
 15 | The Tortured Poets Department |         2024 |         3
 16 | Grimbly                       |         2012 |         1
 17 | Glomblesteen                  |         1997 |         4
(17 rows)

music_library2=# UPDATE artists SET name = 'Nina Simone (nee Eunice Kathleen Waymon)' WHERE id = 4;
UPDATE 1
music_library2=# SELECT * FROM artists;
 id |                   name                   | genre 
----+------------------------------------------+-------
  1 | Pixies                                   | Rock
  2 | ABBA                                     | Pop
  3 | Taylor Swift                             | Pop
  5 | Talking Heads                            | Pop
  4 | Nina Simone (nee Eunice Kathleen Waymon) | Jazz
(5 rows)

music_library2=# UPDATE artists SET genre = 'Popular Music' WHERE genre = pop;
ERROR:  column "pop" does not exist
LINE 1: ...PDATE artists SET genre = 'Popular Music' WHERE genre = pop;
                                                                   ^
music_library2=# UPDATE artists SET genre = 'Popular Music' WHERE genre = 'pop';
UPDATE 0
music_library2=# UPDATE artists SET genre = 'Popular Music' WHERE genre = Pop;
ERROR:  column "pop" does not exist
LINE 1: ...PDATE artists SET genre = 'Popular Music' WHERE genre = Pop;
                                                                   ^
music_library2=# UPDATE artists SET genre = 'Popular Music' WHERE genre = 'Pop';
UPDATE 3
music_library2=# SELECT * FROM albums;
 id |             title             | release_year | artist_id 
----+-------------------------------+--------------+-----------
  1 | Doolittle                     |         1989 |         1
  2 | Surfer Rosa                   |         1988 |         1
  3 | Waterloo                      |         1974 |         2
  4 | Super Trouper                 |         1980 |         2
  5 | Bossanova                     |         1990 |         1
  6 | Lover                         |         2019 |         3
  7 | Folklore                      |         2020 |         3
  8 | I Put a Spell on You          |         1965 |         4
  9 | Baltimore                     |         1978 |         4
 10 | Here Comes the Sun            |         1971 |         4
 11 | Fodder on My Wings            |         1982 |         4
 12 | Ring Ring                     |         1973 |         2
 13 | Creatures of Love             |         1982 |         5
 14 | Mama Mamia                    |         2002 |         2
 15 | The Tortured Poets Department |         2024 |         3
 16 | Grimbly                       |         2012 |         1
 17 | Glomblesteen                  |         1997 |         4
(17 rows)

music_library2=# SELECT * FROM artists;
 id |                   name                   |     genre     
----+------------------------------------------+---------------
  1 | Pixies                                   | Rock
  4 | Nina Simone (nee Eunice Kathleen Waymon) | Jazz
  2 | ABBA                                     | Popular Music
  3 | Taylor Swift                             | Popular Music
  5 | Talking Heads                            | Popular Music
(5 rows)

music_library2=# DELETE FROM albums WHERE id = 12 or release_year > 1995 or artist_id = 2;
DELETE 9
music_library2=# SELECT * FROM albums;
 id |        title         | release_year | artist_id 
----+----------------------+--------------+-----------
  1 | Doolittle            |         1989 |         1
  2 | Surfer Rosa          |         1988 |         1
  5 | Bossanova            |         1990 |         1
  8 | I Put a Spell on You |         1965 |         4
  9 | Baltimore            |         1978 |         4
 10 | Here Comes the Sun   |         1971 |         4
 11 | Fodder on My Wings   |         1982 |         4
 13 | Creatures of Love    |         1982 |         5
(8 rows)