
music_library=# SELECT * FROM albums;
 id |        title         | release_year | artist_id 
----+----------------------+--------------+-----------
  1 | Doolittle            |         1989 |         1
  2 | Surfer Rosa          |         1988 |         1
  3 | Waterloo             |         1974 |         2
  4 | Super Trouper        |         1980 |         2
  5 | Bossanova            |         1990 |         1
  6 | Lover                |         2019 |         3
  7 | Folklore             |         2020 |         3
  8 | I Put a Spell on You |         1965 |         4
  9 | Baltimore            |         1978 |         4
 10 | Here Comes the Sun   |         1971 |         4
 11 | Fodder on My Wings   |         1982 |         4
 12 | Ring Ring            |         1973 |         2
(12 rows)

music_library=# SELECT * FROM albums WHERE release_year BETWEEN 1980 AND 1990;
 id |       title        | release_year | artist_id 
----+--------------------+--------------+-----------
  1 | Doolittle          |         1989 |         1
  2 | Surfer Rosa        |         1988 |         1
  4 | Super Trouper      |         1980 |         2
  5 | Bossanova          |         1990 |         1
 11 | Fodder on My Wings |         1982 |         4
(5 rows)